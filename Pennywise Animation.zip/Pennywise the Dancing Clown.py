####################################################################
#                                                                  #
#               Title: Pennywise the Dancing Clown                 #
#               Programmer: Jeffery Liu                            #
#               Last Modified: 11/09/2017                          #
#                                                                  #
####################################################################

from tkinter import *
from random import *
from math import *
from time import *

myInterface = Tk()
screen = Canvas(myInterface, width=1250, height=700, background="DeepSkyBlue2")
screen.pack()

#Import Pennywise images
clownStanding = PhotoImage(file="PennywiseStanding.gif")
clownFace = PhotoImage(file="PennywiseFace.gif")

#Setting up sky position & sky and grass colours
y = 0
y2 = 100
skyOptions = ["grey1","grey6","grey9","grey11","grey16","grey21","grey26","grey29","grey31","grey36","grey41","grey46","grey49",
              "grey51","grey56","grey61","grey66","grey69","grey71","grey76","grey81","grey86","grey89","grey91","grey96"]
grassColours = ["khaki4", "lightgoldenrod4"]

##BACKGROUND

#Gradient sky
for sky in range(1,100):
    skyColour = (skyOptions[sky%25]) 
    screen.create_rectangle(0,y,1250,y2, fill=skyColour, outline=skyColour)
    y = y + 30
    y2 = y2 + 30

#Clouds
for clouds1 in range(50):
    x = randint(50,275)
    y = randint(100,150)
    screen.create_oval(x,y,x+80,y+50, fill="gainsboro", outline="gainsboro")

for clouds2 in range(15):
    x = randint(400,500)
    y = randint(200,250)
    screen.create_oval(x,y,x+80,y+50, fill="lavender", outline="lavender")

for clouds3 in range(57):
    x = randint(800,1125)
    y = randint(75,125)
    screen.create_oval(x,y,x+80,y+50, fill="gainsboro", outline="gainsboro")

#Ground
screen.create_polygon(0,700,0,585,250,550,475,575,1050,525,1250,600,1250,700, fill="#5C4A3C", outline="#5C4A3C")

#Grass
for grass in range(2100):
    x = randint(0,1250)
    y = randint(600,725)
    direction = randint(0,25)
    length = randint(50,225)
    screen.create_line(x,y,x+direction,y-length, fill=grassColours[grass%2])

##ANIMATION
    
#Constant values
numBalloons = 17
#Position of Pennywise image
pennywiseX = 625
pennywiseY = 1100

#Setting up arrays to create balloons
radius = []
x = [] 
y = []
xSpeed= []
ySpeed = []
balloonTop = []
string = []
knot = []
balloonBottom = []
balloonCentre = []

#Adding values to arrays for positions of balloons
for i in range(numBalloons):
    radius.append(randint(35,60))
    x.append(randint(100,1150))
    y.append(randint(700,750))
    xSpeed.append(uniform(-1.5,1.5))
    ySpeed.append(uniform(1.5,3))
    balloonTop.append(0)
    string.append(0)
    knot.append(0)
    balloonBottom.append(0)
    balloonCentre.append(0)

#Pennywise image moves into the frame from the bottom 
for clown in range(135):
    pennywise = screen.create_image(pennywiseX,pennywiseY, image=clownStanding)
    pennywiseY = pennywiseY - 5

    if pennywiseY <= 500:
        pennywiseY = pennywiseY
        
    screen.update()
    sleep(0.03)
    
    for clown in range(100):
        screen.delete(pennywise)

#Pennywise image stops moving 
pennywiseStop = screen.create_image(pennywiseX,pennywiseY, image=clownStanding)

#Animates balloons moving
for f in range(300):
    
    #Draws multiple balloons
    for i in range(numBalloons):
        balloonTop[i] = screen.create_oval(x[i]-radius[i],y[i]-radius[i],x[i]+radius[i],y[i]+radius[i], fill="#f00000", outline="firebrick1", width=3)
        string[i] = screen.create_line(x[i],y[i]+radius[i]*1,x[i],y[i]+radius[i]*5, fill="white", width=3)
        knot[i] = screen.create_polygon(x[i],y[i]+radius[i]*1.42,x[i]-radius[i]*0.2,y[i]+radius[i]*1.67,x[i]+radius[i]*0.2,y[i]+radius[i]*1.67, fill="#f00000", outline="firebrick1", width=2)
        balloonBottom[i] = screen.create_polygon(x[i]-radius[i],y[i],x[i]-radius[i],y[i],x[i]-radius[i]/1.25,y[i]+radius[i]*1,x[i],y[i]+radius[i]*1.65,x[i]+radius[i]/1.25,y[i]+radius[i]*1,
                                                 x[i]+radius[i],y[i],x[i]+radius[i],y[i], fill="#f00000", outline="firebrick1", width=3, smooth="true")
        balloonCentre[i] = screen.create_polygon(x[i]-radius[i]*0.8,y[i]+radius[i]*0.45,x[i]-radius[i]*0.8,y[i]+radius[i]*0.45,x[i]-radius[i]/1.03,y[i]+radius[i]*0.3,
                                                 x[i]-radius[i],y[i]-3,x[i]-radius[i],y[i]-3,x[i]+radius[i],y[i]-3,x[i]+radius[i],y[i]-3,x[i]+radius[i]/1.03,y[i]+radius[i]*0.3,
                                                 x[i]+radius[i]*0.8,y[i]+radius[i]*0.45,x[i]+radius[i]*0.8,y[i]+radius[i]*0.45, fill="#f00000", smooth="true")

        #Stops balloons at a certain height
        if y[i] <= 200:
            xSpeed[i] = 0
            ySpeed[i] = 0

            #Stops balloons growing 
            for i in range(numBalloons):
                if radius[i] >= 300:
                    radius[i] = radius[i]
                    #Deletes Pennywise image
                    screen.delete(pennywiseStop)
                    #Deletes each balloon (pops)
                    screen.delete(balloonTop[i],knot[i],string[i],balloonBottom[i],balloonCentre[i])

                #Makes balloon larger and fill up screen
                else:
                    radius[i] = radius[i] * 1.1

        #Direction and speed of balloons floating up
        else: 
            x[i] = x[i] + xSpeed[i]        
            y[i] = y[i] - ySpeed[i]

    #Animates movement of balloon
    screen.update()
    sleep(0.03)

    #Deletes balloons in each frame
    for i in range(numBalloons):
        screen.delete(balloonTop[i],string[i],knot[i],balloonBottom[i],balloonCentre[i])

##FINAL SCENE
        
#Pennywise appears again and screen flashes 
flashingColour = ["#f00000", "black"]

for i in range(100):
    screen.create_rectangle(0,0,1250,700, fill=flashingColour[i%2])
    pennywisePopUp = screen.create_image(625,350, image=clownFace) 

    screen.update()
    sleep(0.01)
    screen.delete(pennywisePopUp)
