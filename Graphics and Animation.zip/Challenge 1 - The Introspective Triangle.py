from tkinter import *
from random import *

myInterface = Tk()
screen = Canvas(myInterface, width=600, height=600, background="DodgerBlue")
screen.pack()

num = int(input("How many triangles would you like to draw? (1 to 8): ")) 

x1 = randint(0,601) 
y1 = 0
x2 = 0
y2 = randint(400,600) 
x3 = 600
y3 = randint(400,600)

while num < 1 or num > 8:
    num = int(input("Please input a number between 1 and 8: ")) 

colour = "Gold"

for t in range(num):
    
    screen.create_polygon(x1,y1,x2,y2,x3,y3, fill=colour)

    if colour == "Gold":
        colour = "DodgerBlue"

    else:
        colour = "Gold"

    xx1 = x1
    yy1 = y1 
    x1 = (x1+x2)/2
    y1 = (y1+y2)/2
    x2 = (x2+x3)/2
    y2 = (y2+y3)/2
    x3 = (x3+xx1)/2
    y3 = (y3+yy1)/2

    screen.update()
