from tkinter import *
from random import *
from time import *

myInterface = Tk()
screen = Canvas(myInterface, width=600, height=600, background="black")
screen.pack()

currentLength = 15
currentDirection = "East"

x1 = 300
y1 = 300

for a in range(600):
    
    if currentDirection == "East":
        x2 = x1 + currentLength
        y2 = y1
        colour = "Yellow"
        currentDirection = "North"

    elif currentDirection == "North":
        x2 = x1 
        y2 = y1 - currentLength
        colour = "Blue"
        currentDirection = "West"
        
    elif currentDirection == "West":
        x2 = x1 - currentLength
        y2 = y1 
        colour = "Red"
        currentDirection = "South"
        
    else:
        x2 = x1
        y2 = y1 + currentLength
        colour = "Green2"
        currentDirection = "East"
        
    screen.create_line(x1, y1, x2, y2, fill=colour)

    screen.update()
    sleep(0.03)  
    
    currentLength = currentLength + 5
    x1 = x2
    y1 = y2


    
