from tkinter import *
from random import *
from math import *

myInterface = Tk()
screen = Canvas(myInterface, width=600, height=600, background="White")
screen.pack()

for r in range(13000):
    x = randint(0,600)
    y = randint(0,600)

    distance = sqrt((x-300)**2 + (y-300)**2)
    
    if distance >= 300:
        screen.create_oval(x, y, x+3, y+3, fill="black", outline="black")
    elif distance >= 200:
        screen.create_oval(x, y, x+3, y+3, fill="green2", outline="green2")
    elif distance >= 100:
        screen.create_oval(x, y, x+3, y+3, fill="blue", outline="blue")
    else:
        screen.create_oval(x, y, x+3, y+3, fill="red", outline="red")

screen.update()
