#Brushing Teeth#

from tkinter import *
from time import *
from math import *

myInterface = Tk()
screen = Canvas(myInterface, width=600, height=600, background="pale turquoise")
screen.pack()

a = 45 #height of brush wave
b = 0.1 #frequency of brush wave
c = 140 #y-axis of brush
s = 5 #brush wave speed

screen.create_polygon(150,300,140,580,460,580,450,300, fill="tan1", outline="tan2", width=5)
screen.create_polygon(-50,610,-50,580,50,520,140,465,140,465,300,500,460,465,460,465,550,520,650,580,650,610, fill="darkorchid1", outline="darkorchid3", width=5, smooth="true")
screen.create_polygon(19,0,20,0,50,175,150,310,300,390,450,310,550,175,580,0,581,1, fill="tan1", outline="tan2", width=5, smooth="true")
screen.create_polygon(450,80,300,90,150,80,100,70,100,70,150,150,300,240,450,150,500,70,500,70, fill="khaki", outline="black", width=3, smooth="true")
screen.create_line(85,80,100,70,100,70,115,50, fill="black", width=3, smooth="true")
screen.create_line(485,50,500,70,500,70,515,80, fill="black", width=3, smooth="true")
screen.create_line(250,290,300,340,350,290, fill="black", width=3, smooth="true")
screen.create_line(126,110,126,110,200,145,300,155,400,145,474,110,474,110, fill="black", width=3, smooth="true")

for f in range(70):
    x1 = s*f - 50
    y1 = a*sin(b*f)+c
    x2 = x1+270
    y2 = y1+5

    toothbrushHandle = screen.create_polygon(x1+10,y1-5,x1,y1,x1-3,y1+20,x1+10,y1+25,x2+1,y2+25,x2,y2,x2-10,y2-5, fill="DodgerBlue", outline="blue", width=2, smooth="true")
    bristles = screen.create_rectangle(x2,y2-20,x2+50,y2+1, fill="ghostwhite", outline="black")
    toothbrush = screen.create_polygon(x2-7,y2,x2-7,y2-15,x2+50,y2-15,x2+50,y2,x2+50,y2+15,x2+50,y2+30,x2-7,y2+30,x2-7,y2+15, fill="DodgerBlue", outline="blue", width=2, smooth="true")
    
    screen.update()
    sleep(0.03)
    screen.delete(toothbrushHandle, bristles, toothbrush)

screen.create_polygon(450,80,300,90,150,80,100,70,100,70,150,150,300,240,450,150,500,70,500,70, fill="white", outline="black", width=3, smooth="true")
screen.create_line(126,110,126,110,200,145,300,155,400,145,474,110,474,110, fill="black", width=3, smooth="true")

for f in range(780):
    toothbrushHandle = screen.create_polygon(x1+10,y1-5,x1,y1,x1-3,y1+20,x1+10,y1+25,x2+1,y2+25,x2,y2,x2-10,y2-5, fill="DodgerBlue", outline="blue", width=2, smooth="true")
    bristles = screen.create_rectangle(x2,y2-20,x2+50,y2+1, fill="ghost white", outline="black")
    toothbrush = screen.create_polygon(x2-7,y2,x2-7,y2-15,x2+50,y2-15,x2+50,y2,x2+50,y2+15,x2+50,y2+30,x2-7,y2+30,x2-7,y2+15, fill="DodgerBlue", outline="blue", width=2, smooth="true")
    
    screen.update()
    sleep(0.03)
    screen.delete(toothbrushHandle, bristles, toothbrush)

    x1 = x1 - 5
    y1 = y1 + 5
    x2 = x1+270
    y2 = y1+5
    
