from tkinter import *
from random import *
from time import *

myInterface = Tk()
screen = Canvas(myInterface, width=600, height=600, background="black")
screen.pack()

x1 = 0
y1 = 0 
x2 = 600 
y2 = 600

a1 = 100
b1 = 200

aSpeed = 10
bSpeed = -6
ballDiameter = 17

for s in range(500):
    boxLength = x2 - x1 

    if boxLength <= ballDiameter:
        box = screen.create_rectangle(x1, y1, x2, y2, fill="black", outline="yellow", width=2)
        ball = screen.create_oval(a1, b1, a2, b2, fill="hot pink", outline="hot pink")    

    else:
        x1 = x1 + 1
        y1 = y1 + 1
        x2 = x2 - 1
        y2 = y2 - 1

        a1 = a1 + aSpeed  
        b1 = b1 + bSpeed
        a2 = a1 + ballDiameter
        b2 = b1 + ballDiameter
        
        if a1 <= x1:
            a1 = x1
            a2 = a1 + ballDiameter
            aSpeed = -1 * aSpeed

        if a2 >= x2:
            a2 = x2
            a1 = a2 - ballDiameter  
            aSpeed = -1 * aSpeed

        if b1 <= y1:
            b1 = y1
            b2 = b1 + ballDiameter
            bSpeed = -1 * bSpeed

        if b2 >= y2:
            b2 = y2
            b1 = b2 - ballDiameter
            bSpeed = -1 * bSpeed

        box = screen.create_rectangle(x1, y1, x2, y2, fill="black", outline="yellow", width=2)

        ball = screen.create_oval(a1, b1, a2, b2, fill="hot pink", outline="hot pink")    
    
        screen.update()
        sleep(0.03)
        screen.delete(box, ball)
